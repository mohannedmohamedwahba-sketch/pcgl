package com.pcgamelauncher.data

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Copies a SAF-picked folder into app-private storage so Wine can use real file paths. */
object FolderImporter {

    suspend fun copy(
        context: Context,
        source: DocumentFile,
        dest: File,
        onProgress: (copiedBytes: Long, totalBytes: Long) -> Unit,
    ) = withContext(Dispatchers.IO) {
        val total = totalSize(source)
        var done = 0L
        val buffer = ByteArray(256 * 1024)

        fun copyDir(src: DocumentFile, dst: File) {
            dst.mkdirs()
            for (f in src.listFiles()) {
                val name = f.name ?: continue
                if (name == ".." || name == ".") continue
                if (f.isDirectory) {
                    copyDir(f, File(dst, name))
                } else {
                    context.contentResolver.openInputStream(f.uri)?.use { input ->
                        File(dst, name).outputStream().use { output ->
                            while (true) {
                                val n = input.read(buffer)
                                if (n < 0) break
                                output.write(buffer, 0, n)
                                done += n
                                onProgress(done, total)
                            }
                        }
                    }
                }
            }
        }

        copyDir(source, dest)
    }

    private fun totalSize(dir: DocumentFile): Long =
        dir.listFiles().sumOf { if (it.isDirectory) totalSize(it) else it.length() }
}
