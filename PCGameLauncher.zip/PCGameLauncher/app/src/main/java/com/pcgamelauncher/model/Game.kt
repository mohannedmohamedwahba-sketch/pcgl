package com.pcgamelauncher.model

import org.json.JSONObject

/**
 * A game imported into the launcher.
 *
 * [dirPath] is a real filesystem path inside the app's private storage: Wine needs
 * normal file paths, it cannot read Android content:// URIs, so imported folders are copied.
 * [exeRelPath] is the executable's path relative to [dirPath], using '/' separators.
 */
data class Game(
    val id: String,
    val name: String,
    val dirPath: String,
    val exeRelPath: String,
    val resolution: String = "1280x720",
    val graphicsDriver: String = "turnip",
    val box64Preset: String = "compatibility",
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("dirPath", dirPath)
        .put("exeRelPath", exeRelPath)
        .put("resolution", resolution)
        .put("graphicsDriver", graphicsDriver)
        .put("box64Preset", box64Preset)

    companion object {
        fun fromJson(o: JSONObject) = Game(
            id = o.getString("id"),
            name = o.getString("name"),
            dirPath = o.getString("dirPath"),
            exeRelPath = o.getString("exeRelPath"),
            resolution = o.optString("resolution", "1280x720"),
            graphicsDriver = o.optString("graphicsDriver", "turnip"),
            box64Preset = o.optString("box64Preset", "compatibility"),
        )
    }
}
