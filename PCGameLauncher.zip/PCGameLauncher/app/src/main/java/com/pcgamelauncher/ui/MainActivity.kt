package com.pcgamelauncher.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pcgamelauncher.model.Game

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme { MainScreen(vm, onLaunch = ::launchGame) }
        }
    }

    private fun launchGame(game: Game) {
        startActivity(Intent(this, GameActivity::class.java).putExtra(GameActivity.EXTRA_GAME_ID, game.id))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScreen(vm: MainViewModel, onLaunch: (Game) -> Unit) {
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.onFolderPicked(uri)
    }
    val runtimePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.installRuntime(uri)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("مشغّل ألعاب الكمبيوتر") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { folderPicker.launch(null) },
                text = { Text("إضافة لعبة (فولدر)") },
                icon = { Text("+") },
            )
        },
    ) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            RuntimeCard(vm.runtimeInstalled) { runtimePicker.launch(arrayOf("application/zip", "application/octet-stream")) }

            if (vm.games.isEmpty()) {
                Text("لا توجد ألعاب بعد. اضغط «إضافة لعبة» واختر فولدر اللعبة.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(vm.games, key = { it.id }) { game ->
                        GameRow(game, vm.runtimeInstalled, onLaunch = { onLaunch(game) }, onDelete = { vm.deleteGame(game) })
                    }
                }
            }
        }
    }

    vm.pending?.let { p ->
        AlertDialog(
            onDismissRequest = vm::cancelImport,
            title = { Text("اختر الملف التنفيذي الرئيسي") },
            text = {
                LazyColumn {
                    items(p.candidates.take(15)) { c ->
                        Column(
                            Modifier.fillMaxWidth().clickable { vm.confirmImport(c) }.padding(vertical = 8.dp),
                        ) {
                            Text(c.relPath, style = MaterialTheme.typography.bodyMedium)
                            Text("${c.sizeBytes / 1024 / 1024} MB", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = vm::cancelImport) { Text("إلغاء") } },
        )
    }

    vm.busyMessage?.let { msg ->
        AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            text = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    CircularProgressIndicator()
                    Text(msg)
                }
            },
        )
    }

    vm.errorMessage?.let { msg ->
        AlertDialog(
            onDismissRequest = { vm.errorMessage = null },
            confirmButton = { TextButton(onClick = { vm.errorMessage = null }) { Text("حسناً") } },
            text = { Text(msg) },
        )
    }
}

@Composable
private fun RuntimeCard(installed: Boolean, onInstall: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                if (installed) "محرك التشغيل (Box64 + Wine): مثبّت ✔" else "محرك التشغيل (Box64 + Wine): غير مثبّت",
                style = MaterialTheme.typography.titleSmall,
            )
            if (!installed) {
                Text("اختر ملف zip للمحرك لتتمكن من تشغيل الألعاب. التفاصيل في README.", style = MaterialTheme.typography.bodySmall)
            }
            OutlinedButton(onClick = onInstall) { Text(if (installed) "إعادة التثبيت" else "تثبيت المحرك من ملف zip") }
        }
    }
}

@Composable
private fun GameRow(game: Game, canRun: Boolean, onLaunch: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Column(Modifier.weight(1f)) {
                Text(game.name, style = MaterialTheme.typography.titleMedium)
                Text(game.exeRelPath, style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onDelete) { Text("حذف") }
            Button(onClick = onLaunch, enabled = canRun) { Text("تشغيل") }
        }
    }
}
