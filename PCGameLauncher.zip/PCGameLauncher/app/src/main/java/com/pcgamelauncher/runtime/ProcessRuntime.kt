package com.pcgamelauncher.runtime

import android.content.Context
import com.pcgamelauncher.model.Game
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File

/**
 * Runs `box64 wine64 <game.exe>` as a child process.
 *
 * What this class does: builds the command line and environment, launches the process,
 * streams its output, and can kill it.
 * What it does NOT do: draw anything. Wine needs an X11 server to show a window.
 * That is the job of a display layer (see GameActivity / README, "Display layer").
 */
class ProcessRuntime(private val context: Context) : PcRuntime {

    private val root = RuntimeInstaller.runtimeDir(context)
    private val box64 get() = File(root, "bin/box64")
    private val wine get() = File(root, "wine/bin/wine64")

    override fun isInstalled() = box64.canExecute() && wine.exists()

    override fun launch(game: Game): RunningGame {
        check(isInstalled()) { "محرك التشغيل غير مثبّت" }

        val prefix = File(context.filesDir, "prefixes/${game.id}").apply { mkdirs() }
        val gameDir = File(game.dirPath)
        val exe = File(gameDir, game.exeRelPath)
        val workDir = exe.parentFile ?: gameDir

        val cmd = listOf(box64.absolutePath, wine.absolutePath, exe.absolutePath)
        val builder = ProcessBuilder(cmd)
            .directory(workDir)
            .redirectErrorStream(true)

        builder.environment().apply {
            put("HOME", context.filesDir.absolutePath)
            put("WINEPREFIX", prefix.absolutePath)
            put("WINEDEBUG", "-all")
            put("DISPLAY", ":0")
            put("BOX64_LD_LIBRARY_PATH", File(root, "libs").absolutePath)
            put("BOX64_PATH", File(root, "bin").absolutePath)
            put("LD_LIBRARY_PATH", File(root, "libs").absolutePath)
            put("WINEARCH", "win64")
            put("MESA_VK_WSI_PRESENT_MODE", "mailbox")
            put("GAME_RESOLUTION", game.resolution)
            put("GRAPHICS_DRIVER", game.graphicsDriver)
            applyBox64Preset(game.box64Preset)
        }

        return ProcessRunningGame(builder.start())
    }

    private fun MutableMap<String, String>.applyBox64Preset(preset: String) {
        when (preset) {
            "performance" -> {
                put("BOX64_DYNAREC_SAFEFLAGS", "0")
                put("BOX64_DYNAREC_FASTNAN", "1")
                put("BOX64_DYNAREC_BIGBLOCK", "3")
            }
            else -> { // "compatibility"
                put("BOX64_DYNAREC_SAFEFLAGS", "2")
                put("BOX64_DYNAREC_FASTNAN", "0")
                put("BOX64_DYNAREC_BIGBLOCK", "1")
            }
        }
    }

    private class ProcessRunningGame(private val process: Process) : RunningGame {
        override val output: Flow<String> = flow {
            process.inputStream.bufferedReader().useLines { lines ->
                for (line in lines) emit(line)
            }
            emit("— انتهت العملية (الرمز ${process.waitFor()}) —")
        }.flowOn(Dispatchers.IO)

        override fun isAlive() = process.isAlive

        override fun stop() {
            process.destroy()
            if (process.isAlive) process.destroyForcibly()
        }
    }
}
