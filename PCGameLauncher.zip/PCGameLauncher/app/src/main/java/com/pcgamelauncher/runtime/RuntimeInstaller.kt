package com.pcgamelauncher.runtime

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipInputStream

/**
 * Unpacks an engine bundle (a .zip the user picks) into <filesDir>/runtime.
 *
 * Expected layout inside the zip (see README):
 *   bin/box64
 *   wine/bin/wine64        (plus wine/lib, wine/share ...)
 *   libs/                  (arm64 shared libraries Box64 needs, optional)
 */
object RuntimeInstaller {

    fun runtimeDir(context: Context) = File(context.filesDir, "runtime")

    suspend fun installFromZip(context: Context, zip: Uri) = withContext(Dispatchers.IO) {
        val root = runtimeDir(context)
        root.deleteRecursively()
        root.mkdirs()
        val rootCanonical = root.canonicalPath + File.separator

        val stream = context.contentResolver.openInputStream(zip)
            ?: error("تعذّر فتح الملف")
        ZipInputStream(stream.buffered()).use { zin ->
            while (true) {
                val entry = zin.nextEntry ?: break
                val out = File(root, entry.name)
                // Zip-slip protection: never write outside the runtime folder.
                if (!out.canonicalPath.startsWith(rootCanonical)) continue
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zin.copyTo(it) }
                }
            }
        }

        listOf("bin", "wine/bin").forEach { dir ->
            File(root, dir).listFiles()?.forEach { it.setExecutable(true, false) }
        }
    }
}
