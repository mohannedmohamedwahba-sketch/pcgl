package com.pcgamelauncher.runtime

import com.pcgamelauncher.model.Game
import kotlinx.coroutines.flow.Flow

/**
 * The seam between the launcher and whatever actually executes Windows programs.
 * The UI only talks to this interface, so the engine can be swapped
 * (Box64 + Wine today, anything else later) without touching the screens.
 */
interface PcRuntime {
    /** True when all required engine files are present on the device. */
    fun isInstalled(): Boolean

    /** Starts [game] and returns a handle to the running process. */
    fun launch(game: Game): RunningGame
}

interface RunningGame {
    /** Combined stdout/stderr of the engine, line by line. Completes when the process exits. */
    val output: Flow<String>

    fun isAlive(): Boolean

    fun stop()
}
