package com.pcgamelauncher.data

import androidx.documentfile.provider.DocumentFile

/**
 * Walks a picked game folder (before copying) and ranks the .exe files so the most
 * likely main executable comes first. Installers, redistributables and crash handlers
 * are pushed to the bottom.
 */
object ExeScanner {

    data class Candidate(val relPath: String, val sizeBytes: Long, val score: Int)

    private val junkMarkers = listOf(
        "unins", "setup", "install", "redist", "vcredist", "dxsetup", "dotnet",
        "crash", "helper", "updater", "update", "launcherprep", "ue4prereq", "oalinst",
    )

    fun scan(root: DocumentFile, maxDepth: Int = 4): List<Candidate> {
        val found = mutableListOf<Candidate>()

        fun walk(dir: DocumentFile, prefix: String, depth: Int) {
            if (depth > maxDepth) return
            for (f in dir.listFiles()) {
                val name = f.name ?: continue
                if (f.isDirectory) {
                    walk(f, "$prefix$name/", depth + 1)
                } else if (name.endsWith(".exe", ignoreCase = true)) {
                    found += Candidate(prefix + name, f.length(), score(name, f.length(), depth))
                }
            }
        }

        walk(root, "", 0)
        return found.sortedByDescending { it.score }
    }

    private fun score(name: String, size: Long, depth: Int): Int {
        var s = 100 - depth * 15
        val lower = name.lowercase()
        if (junkMarkers.any { lower.contains(it) }) s -= 60
        s += (size / (50L * 1024 * 1024)).coerceAtMost(30).toInt()
        return s
    }
}
