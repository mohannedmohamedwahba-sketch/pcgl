package com.pcgamelauncher.ui

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pcgamelauncher.data.ExeScanner
import com.pcgamelauncher.data.FolderImporter
import com.pcgamelauncher.data.GameStore
import com.pcgamelauncher.model.Game
import com.pcgamelauncher.runtime.ProcessRuntime
import com.pcgamelauncher.runtime.RuntimeInstaller
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/** A folder the user picked that is waiting for them to choose its main .exe. */
data class PendingImport(
    val uri: Uri,
    val folderName: String,
    val candidates: List<ExeScanner.Candidate>,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = GameStore(app)
    private val runtime = ProcessRuntime(app)

    var games by mutableStateOf(store.load())
        private set
    var runtimeInstalled by mutableStateOf(runtime.isInstalled())
        private set
    var pending by mutableStateOf<PendingImport?>(null)
        private set

    /** Non-null while something long is running (scanning, copying, installing). */
    var busyMessage by mutableStateOf<String?>(null)
        private set
    var errorMessage by mutableStateOf<String?>(null)

    fun onFolderPicked(uri: Uri) {
        viewModelScope.launch {
            busyMessage = "جارٍ فحص المجلد…"
            try {
                val (name, candidates) = withContext(Dispatchers.IO) {
                    val doc = DocumentFile.fromTreeUri(getApplication(), uri)
                        ?: error("تعذّر فتح المجلد")
                    (doc.name ?: "Game") to ExeScanner.scan(doc)
                }
                if (candidates.isEmpty()) {
                    errorMessage = "لم أجد أي ملف .exe داخل هذا المجلد"
                } else {
                    pending = PendingImport(uri, name, candidates)
                }
            } catch (e: Exception) {
                errorMessage = e.message ?: "فشل فحص المجلد"
            } finally {
                busyMessage = null
            }
        }
    }

    fun cancelImport() {
        pending = null
    }

    fun confirmImport(exe: ExeScanner.Candidate) {
        val p = pending ?: return
        pending = null
        viewModelScope.launch {
            val id = UUID.randomUUID().toString()
            val dest = File(getApplication<Application>().filesDir, "games/$id")
            try {
                val doc = DocumentFile.fromTreeUri(getApplication(), p.uri)
                    ?: error("تعذّر فتح المجلد")
                FolderImporter.copy(getApplication(), doc, dest) { done, total ->
                    val pct = if (total > 0) (done * 100 / total).toInt() else 0
                    busyMessage = "جارٍ نسخ اللعبة… $pct%"
                }
                val game = Game(id = id, name = p.folderName, dirPath = dest.absolutePath, exeRelPath = exe.relPath)
                games = games + game
                store.save(games)
            } catch (e: Exception) {
                dest.deleteRecursively()
                errorMessage = e.message ?: "فشل نسخ اللعبة"
            } finally {
                busyMessage = null
            }
        }
    }

    fun deleteGame(game: Game) {
        viewModelScope.launch(Dispatchers.IO) {
            File(game.dirPath).deleteRecursively()
            File(getApplication<Application>().filesDir, "prefixes/${game.id}").deleteRecursively()
            withContext(Dispatchers.Main) {
                games = games.filterNot { it.id == game.id }
                store.save(games)
            }
        }
    }

    fun installRuntime(zip: Uri) {
        viewModelScope.launch {
            busyMessage = "جارٍ تثبيت محرك التشغيل…"
            try {
                RuntimeInstaller.installFromZip(getApplication(), zip)
                runtimeInstalled = runtime.isInstalled()
                if (!runtimeInstalled) {
                    errorMessage = "الملف لا يحتوي على bin/box64 و wine/bin/wine64"
                }
            } catch (e: Exception) {
                errorMessage = e.message ?: "فشل التثبيت"
            } finally {
                busyMessage = null
            }
        }
    }
}
