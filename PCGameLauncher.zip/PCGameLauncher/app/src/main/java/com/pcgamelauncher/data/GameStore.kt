package com.pcgamelauncher.data

import android.content.Context
import com.pcgamelauncher.model.Game
import org.json.JSONArray

/** Persists the game library as a JSON list in SharedPreferences. */
class GameStore(context: Context) {
    private val prefs = context.getSharedPreferences("games", Context.MODE_PRIVATE)

    fun load(): List<Game> {
        val arr = JSONArray(prefs.getString(KEY, "[]"))
        return List(arr.length()) { Game.fromJson(arr.getJSONObject(it)) }
    }

    fun save(games: List<Game>) {
        val arr = JSONArray()
        games.forEach { arr.put(it.toJson()) }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    fun get(id: String): Game? = load().firstOrNull { it.id == id }

    private companion object {
        const val KEY = "list"
    }
}
