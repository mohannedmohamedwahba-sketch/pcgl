package com.pcgamelauncher.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.pcgamelauncher.data.GameStore
import com.pcgamelauncher.runtime.ProcessRuntime
import com.pcgamelauncher.runtime.RunningGame
import kotlinx.coroutines.launch

/**
 * Hosts a running game.
 *
 * Current state: starts the engine process and shows its live log.
 * Display layer (NOT implemented): Wine draws through X11, so a real game window needs an
 * X server implementation rendering into a SurfaceView, plus input mapping (touch -> mouse,
 * gamepad -> XInput). Plug it in here: create the display view, start the X server BEFORE
 * calling runtime.launch(), and forward touch/key events to it.
 */
class GameActivity : ComponentActivity() {
    private var running: RunningGame? = null
    private val log = mutableStateListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val game = intent.getStringExtra(EXTRA_GAME_ID)?.let { GameStore(this).get(it) }
        if (game == null) {
            finish()
            return
        }

        setContent {
            MaterialTheme {
                LogScreen(title = game.name, lines = log, onStop = { finish() })
            }
        }

        lifecycleScope.launch {
            try {
                val handle = ProcessRuntime(this@GameActivity).launch(game)
                running = handle
                handle.output.collect { line ->
                    log.add(line)
                    while (log.size > MAX_LINES) log.removeAt(0)
                }
            } catch (e: Exception) {
                log.add("خطأ: ${e.message}")
            }
        }
    }

    override fun onDestroy() {
        running?.stop()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_GAME_ID = "game_id"
        private const val MAX_LINES = 500
    }
}

@Composable
private fun LogScreen(title: String, lines: List<String>, onStop: () -> Unit) {
    val listState = rememberLazyListState()
    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.animateScrollToItem(lines.lastIndex)
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        LazyColumn(Modifier.weight(1f), state = listState) {
            items(lines) { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
        Button(onClick = onStop) { Text("إيقاف وإغلاق") }
    }
}
